//
//  assignment3App.swift
//  assignment3
//
//  Created by Hyunmin Kim on 6/5/2024.
//

import SwiftUI

@main
struct assignment3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
