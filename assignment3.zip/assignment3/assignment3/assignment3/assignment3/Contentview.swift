//
//  assignment3App.swift
//  assignment3
//
//  Created by Hyunmin Kim on 12/5/2024.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            SeatSelectionView()
        }
    }
}

@main
struct MovieTheaterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
