//
//  2.swift
//  assignment3
//
//  Created by Hyunmin Kim on 12/5/2024.
//


import SwiftUI

struct PaymentView: View {
    var totalSelectedSeats: Int
    var totalAmount: Int {
        totalSelectedSeats * 3
    }

    @State private var cardNumber = ""
    @State private var expirationDate = ""
    @State private var cvv = ""
    @State private var selectedPaymentMethod: PaymentMethod = .visa

    enum PaymentMethod: String, CaseIterable, Identifiable {
        case visa = "Visa"
        case masterCard = "MasterCard"
        case amex = "American Express"
        case applePay = "Apple Pay"
        
        var id: Self { self }
        
        var icon: String {
            switch self {
            case .visa: return "creditcard"
            case .masterCard: return "creditcard.fill"
            case .amex: return "creditcard.circle"
            case .applePay: return "applelogo"
            }
        }
    }

    var body: some View {
        VStack(spacing: 20) {
            Text("Enter Payment Information")
                .font(.headline)
                .padding(.top)

            Picker("Payment Method", selection: $selectedPaymentMethod) {
                ForEach(PaymentMethod.allCases) { method in
                    Label(method.rawValue, systemImage: method.icon)
                        .tag(method)
                }
            }
            .pickerStyle(.segmented)

            if selectedPaymentMethod != .applePay {
                Group {
                    TextField("Card Number", text: $cardNumber)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .keyboardType(.numberPad)

                    TextField("Expiration Date", text: $expirationDate)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .keyboardType(.numbersAndPunctuation)

                    TextField("CVV", text: $cvv)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .keyboardType(.numberPad)
                }
            }

            Text("Amount Due: $\(totalAmount)")
                .font(.title2)
                .fontWeight(.bold)

            NavigationLink(destination: ConfirmationView(totalAmount: totalAmount)) {
                Text("Confirm Payment")
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .cornerRadius(10)
            }

            Spacer()
        }
        .padding()
    }
}
