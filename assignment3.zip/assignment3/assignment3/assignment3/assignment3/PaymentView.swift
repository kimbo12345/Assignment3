//
//  2.swift
//  assignment3
//
//  Created by Hyunmin Kim on 12/5/2024.
//

import SwiftUI

struct PaymentView: View {
    var totalSelectedSeats: Int
    var totalAmount: Int {
        totalSelectedSeats * 3
    }

    @State private var cardNumber = ""
    @State private var expirationDate = ""
    @State private var cvv = ""

    var body: some View {
        VStack(spacing: 20) {
            Text("Enter Payment Information").font(.headline)
            Text("Amount Due: $\(totalAmount)").font(.subheadline)
            TextField("Card Number", text: $cardNumber)
                .textFieldStyle(RoundedBorderTextFieldStyle())
            TextField("Expiration Date", text: $expirationDate)
                .textFieldStyle(RoundedBorderTextFieldStyle())
            TextField("CVV", text: $cvv)
                .textFieldStyle(RoundedBorderTextFieldStyle())
            NavigationLink("Confirm Payment", destination: ConfirmationView(totalAmount: totalAmount))
            Spacer()
        }.padding()
    }
}


