//
//  3.swift
//  assignment3
//
//  Created by Hyunmin Kim on 12/5/2024.
//

import SwiftUI

struct ConfirmationView: View {
    var totalAmount: Int

    var body: some View {
        VStack {
            Text("Reservation Confirmation")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.top, 20)

            VStack(alignment: .leading, spacing: 10) {
                Text("Insert movie name")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                Text("Inset time")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                Text("Seats: \(totalAmount / 3)")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                Text("Total Price: $\(totalAmount)")
                    .font(.title2)
                    .fontWeight(.semibold)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()

            Spacer()

            Button(action: {
                print("Reservation Completed.")
            }) {
                Text("Complete Reservation")
                    .font(.title2)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.green)
                    .cornerRadius(10)
            }
            .padding(.horizontal)

            Button(action: {
                print("Booking Canceled.")
            }) {
                Text("Cancel Booking")
                    .font(.title2)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.red)
                    .cornerRadius(10)
            }
            .padding()

        }
        .padding()
    }
}
