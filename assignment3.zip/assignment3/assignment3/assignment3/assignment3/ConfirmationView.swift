//
//  3.swift
//  assignment3
//
//  Created by Hyunmin Kim on 12/5/2024.
//

import SwiftUI

struct ConfirmationView: View {
    var totalAmount: Int

    var body: some View {
        VStack {
            Text("Reservation Confirmation").font(.headline)
            Text("Movie: Sample Movie")
            Text("Time: 7 PM")
            Text("Seats: \(totalAmount / 3)")
            Text("Total Price: $\(totalAmount)")
            Button("Complete Reservation") {
                print("Reservation Completed.")
            }
        }.padding()
    }
}
