//
//  1.swift
//  assignment3
//
//  Created by Hyunmin Kim on 12/5/2024.
//

import SwiftUI

struct SeatSelectionView: View {
    @State private var seats = Array(repeating: Seat(id: 0), count: 30).enumerated().map { index, seat in Seat(id: index) }
    @State private var totalSelectedSeats = 0

    var body: some View {
        VStack {
            Text("Select Seats")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()

            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 20), count: 5), spacing: 20) {
                ForEach($seats.indices, id: \.self) { index in
                    Button(action: {
                        seats[index].isSelected.toggle()
                        totalSelectedSeats = seats.filter { $0.isSelected }.count
                    }) {
                        ZStack {
                            Rectangle()
                                .fill(seats[index].isSelected ? Color.blue : Color.gray)
                                .frame(width: 50, height: 50)
                                .cornerRadius(8)
                                .shadow(radius: seats[index].isSelected ? 10 : 3)
                            Image(systemName: "chair")
                                .foregroundColor(.white)
                        }
                    }
                }
            }

            Text("Selected Seats: \(totalSelectedSeats) - Total: $\(totalSelectedSeats * 3)")
                .font(.title3)
                .fontWeight(.semibold)
                .padding()

            NavigationLink("Next", destination: PaymentView(totalSelectedSeats: totalSelectedSeats))
                .buttonStyle(.borderedProminent)
                .buttonBorderShape(.roundedRectangle(radius: 10))
                .padding()
        }
        .padding()
    }
}
