//
//  1.swift
//  assignment3
//
//  Created by Hyunmin Kim on 12/5/2024.
//

import Foundation

import SwiftUI

struct SeatSelectionView: View {
    @State private var seats = Array(repeating: Seat(id: 0), count: 30).enumerated().map { index, seat in Seat(id: index) }
    @State private var totalSelectedSeats = 0

    var body: some View {
        VStack {
            Text("Select Seats").font(.headline).padding()
            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 5), spacing: 10) {
                ForEach($seats.indices, id: \.self) { index in
                    Button(action: {
                        seats[index].isSelected.toggle()
                        totalSelectedSeats = seats.filter { $0.isSelected }.count
                    }) {
                        Rectangle()
                            .fill(seats[index].isSelected ? Color.blue : Color.gray)
                            .frame(width: 50, height: 50)
                            .cornerRadius(8)
                            .shadow(radius: 3)
                    }
                }
            }
            Text("Selected Seats: \(totalSelectedSeats) - Total: $\(totalSelectedSeats * 3)").font(.subheadline).padding()
            NavigationLink("Next", destination: PaymentView(totalSelectedSeats: totalSelectedSeats))
        }
    }
}
